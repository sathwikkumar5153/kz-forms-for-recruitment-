import { Component,OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators,FormArray} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
   genders = ['male', 'female'];
   signupForm: FormGroup;
   objectData:any;
    ngOnInit(): void {
      this.signupForm = new FormGroup ({
        userData: new FormGroup ({
        'Name': new FormControl('', Validators.required),
        'Registration Number': new FormControl('', Validators.required),
        'Semister': new FormControl('', Validators.required),
        'GitHub Profile': new FormControl('', Validators.required),
 
      }),
    
      })
    }
    onSubmit() {
      console.log(this.signupForm.value.userData);
      this.objectData=this.signupForm.value.userData;
      this.signupForm.reset();
    }
}
